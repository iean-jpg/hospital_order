package com.bean;

import java.math.BigDecimal;

public class Hospitalized {
    private Integer id;

    private String registid;

    private String bednum;

    private double total;

    private double yytotal;

    private double projecttotal;


    private String iscy;

    private String savetime;

    private String cysavetime;

    private double tktotal;

    private double bjtotal;

    private double usertotal;

    private String userid;

    private Registration registration;

    private Sysuser user;

    private String january;

    private String february;


    private String march;

    private String april;

    private String may;


    private String june;

    private String july;

    private String august;

    private String september;

    private String october;

    private String november;

    private String december;


    public String getJanuary() {
        return january;
    }

    public void setJanuary(String january) {
        this.january = january;
    }

    public String getFebruary() {
        return february;
    }

    public void setFebruary(String february) {
        this.february = february;
    }

    public String getMarch() {
        return march;
    }

    public void setMarch(String march) {
        this.march = march;
    }

    public String getApril() {
        return april;
    }

    public void setApril(String april) {
        this.april = april;
    }

    public String getMay() {
        return may;
    }

    public void setMay(String may) {
        this.may = may;
    }

    public String getJune() {
        return june;
    }

    public void setJune(String june) {
        this.june = june;
    }

    public String getJuly() {
        return july;
    }

    public void setJuly(String july) {
        this.july = july;
    }

    public String getAugust() {
        return august;
    }

    public void setAugust(String august) {
        this.august = august;
    }

    public String getOctober() {
        return october;
    }

    public void setOctober(String october) {
        this.october = october;
    }

    public String getNovember() {
        return november;
    }

    public void setNovember(String november) {
        this.november = november;
    }

    public String getDecember() {
        return december;
    }

    public void setDecember(String december) {
        this.december = december;
    }

    public String getSeptember() {
        return september;
    }

    public void setSeptember(String september) {
        this.september = september;
    }

    public Sysuser getUser() {
        return user;
    }

    public void setUser(Sysuser user) {
        this.user = user;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public double getBjtotal() {
        return bjtotal;
    }

    public void setBjtotal(double bjtotal) {
        this.bjtotal = bjtotal;
    }

    public double getUsertotal() {
        return usertotal;
    }

    public void setUsertotal(double usertotal) {
        this.usertotal = usertotal;
    }

    public String getCysavetime() {
        return cysavetime;
    }

    public void setCysavetime(String cysavetime) {
        this.cysavetime = cysavetime;
    }

    public double getTktotal() {
        return tktotal;
    }

    public void setTktotal(double tktotal) {
        this.tktotal = tktotal;
    }


    public double getProjecttotal() {
        return projecttotal;
    }

    public void setProjecttotal(double projecttotal) {
        this.projecttotal = projecttotal;
    }

    public double getYytotal() {
        return yytotal;
    }

    public void setYytotal(double yytotal) {
        this.yytotal = yytotal;
    }

    public Registration getRegistration() {
        return registration;
    }

    public void setRegistration(Registration registration) {
        this.registration = registration;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegistid() {
        return registid;
    }

    public void setRegistid(String registid) {
        this.registid = registid;
    }

    public String getBednum() {
        return bednum;
    }

    public void setBednum(String bednum) {
        this.bednum = bednum;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getIscy() {
        return iscy;
    }

    public void setIscy(String iscy) {
        this.iscy = iscy;
    }

    public String getSavetime() {
        return savetime;
    }

    public void setSavetime(String savetime) {
        this.savetime = savetime;
    }


}