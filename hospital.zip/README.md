# hospyyghsysboot
毕业设计，基于springboot的医院预约挂号系统，前端使用Vue，数据axios。
数据库直接导入。UTF-8格式
主页在文档中。
